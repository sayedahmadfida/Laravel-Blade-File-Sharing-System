<script src="{{ asset('assets/libs/js/jquery-3.7.1.min.js') }}"></script>
<!-- Bootstrap -->
<script src="{{ asset('assets/libs/js/bootstrap.bundle.min.js') }}"></script>
<!-- overlayScrollbars -->
<script src="{{ asset('assets/libs/js/jquery.overlayScrollbars.min.js') }}"></script>
<!-- AdminLTE App -->
<script src="{{ asset('assets/libs/js/adminlte.js') }}"></script>

<script src="{{ asset('assets/libs/js/font.min.js') }}"></script>
<script src="{{ asset('assets/libs/js/jquery.validate.min.js') }}"></script>
<script src="{{ asset('assets/libs/js/sweetalert2@11.js') }}"></script>
<script src="{{ asset('assets/js/custom.js') }}"></script>

