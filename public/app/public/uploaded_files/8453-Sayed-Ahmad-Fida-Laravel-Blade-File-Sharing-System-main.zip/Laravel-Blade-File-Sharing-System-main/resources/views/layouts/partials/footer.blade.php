<footer class="main-footer">
  <strong>Copyright &copy; 2024 <a href="https://www.upwork.com/freelancers/~01d472e65fd61bb5c4" target="_blank">Nisar Ahmad Sahil</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 1.0.0
  </div>
</footer>