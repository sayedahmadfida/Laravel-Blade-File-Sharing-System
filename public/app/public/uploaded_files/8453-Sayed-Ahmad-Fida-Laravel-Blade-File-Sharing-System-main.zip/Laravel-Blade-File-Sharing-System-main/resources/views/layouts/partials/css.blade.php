  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="{{asset('assets/libs/css/all.min.css')}}">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="{{asset('assets/libs/css/OverlayScrollbars.min.css')}}">
  <!-- Theme style -->
  <link rel="stylesheet" href="{{asset('assets/libs/css/adminlte.min.css')}}">
  <script src="{{asset('assets/libs/js/dropzone.min.js')}}"></script>
  <link rel="stylesheet" href="{{asset('assets/libs/css/dropzone.min.css')}}">
  <link rel="stylesheet" href="{{asset('assets/css/custom.css')}}">